const { Client, GatewayIntentBits, Collection } = require("discord.js");
const { readdirSync } = require("fs");
const { token, prefix } = require("./config.json");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const commands = new Collection();
const aliases = new Collection();

client.on("ready", () => {
  const commandsDir = readdirSync("./commands", {}).filter((file) =>
    file.endsWith(".js")
  );

  commandsDir.forEach((fileName) => {
    const command = require("./commands/" + fileName);
    commands.set(command.config.name.toLowerCase(), command.run);
    if (command.config.aliases) {
      command.config.aliases.forEach((alias) => {
        aliases.set(alias.toLowerCase(), command.config.name.toLowerCase());
      });
    }
  });

  console.log(commands);
  console.log(aliases);
});

client.on("messageCreate", (message) => {
  if (message.webhookId) return;
  if (message.author.bot) return;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.replace(prefix, "").split(" ");
  const command = args.shift().toLowerCase();

  try {
    if (command != "") {
      const cmdRun =
        commands.get(command) || commands.get(aliases.get(command));

      if (!cmdRun) {
        return message.reply(`Esse comando não existe ainda!`);
      }

      cmdRun(client, message, args);
    }
  } catch (err) {
    console.error(err);
    message.reply(`Oops aconteceu um erro inexperado \`\`\`js\n${err}\`\`\``);
  }
});

client.login(token);
