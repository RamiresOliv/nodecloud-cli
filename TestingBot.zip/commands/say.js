exports.run = async (client, message, args) => {
  if (args[0] == null) {
    return message.reply(
      "Você precisa enviar junto uma mensagem com o comando!"
    );
  }

  message.delete();
  const customMessage = args.join(" ");
  console.log(customMessage);
  await message.channel.send(customMessage);
};

exports.config = {
  name: "say",
  description: "Faz o bot falar uma mensagem que você definiu.",
  aliases: ["falar", "s"],
};
