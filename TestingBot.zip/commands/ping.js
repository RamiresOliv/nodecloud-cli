exports.run = async (client, message, args) => {
  console.log(args);
  await message.reply(
    "🏓 Pong! " + (Date.now() - message.createdTimestamp) + "MS"
  );
  console.log(
    "A mensagem foi enviada com sucesso! Para " + message.author.username
  );
};

exports.config = {
  name: "ping",
  description: "Mostra o tempo de resposta dos comandos por MS.",
  aliases: ["pingpong"],
};
