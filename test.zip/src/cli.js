const db = require("local-db-express");
const { createReadStream, statSync, readFileSync } = require("fs");
const FormData = require("form-data");
import fetch from "node-fetch";

const formData = new FormData();
formData.append("file", createReadStream("test.zip"), "test.zip");

export async function cli(args) {
  fetch("https://cf18-131-100-62-45.sa.ngrok.io/post", {
    method: "POST",
    headers: {
      "Content-type": "application/json",
    },
    body: JSON.stringify(readFileSync("test.zip")),
  }).then(async (data) => {
    console.log(await data.json());
  });
}
