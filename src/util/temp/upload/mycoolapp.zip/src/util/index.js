exports.Authentification = require("./auth");
exports.Functions = require("./functions");
exports.FileWorker = require("./files");
exports.NodeCloudApi = require("./api");
exports.Tempo = require("./temp");
exports.Exec = require("./exec");
// Selling this product is not allowed.
// Ehh idk if you want to add things here.. Not recomended but ok.
