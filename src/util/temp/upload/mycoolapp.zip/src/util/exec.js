const { spawn, exec } = require("child_process");
const { appendFileSync, openSync } = require("fs");
const { Tempo } = require(".");

// Selling this product is not allowed.
exports.openTXTFile = async (path) => {
  // only opens the notepad and the log file created! No touch here if you don't know how this works!!!!!!! Thank u! Have nice modifications!
};
