var i = 0;

setInterval(() => {
  i += 1;
  console.log("hello world! this are a test! X" + i);
}, 1000);
